package src.Pizzaria.model.Pizza;

import java.util.List;

public class PizzaEspecial extends Pizza{
    private List<Ingrediente> ingredientes;

    public PizzaEspecial(Integer codigo, Double preco, String nome, List<Ingrediente> ingredientes) {
        super(codigo, preco, nome);
        this.ingredientes = ingredientes;
    }

    public List<Ingrediente> getIngredientes() {
        return ingredientes;
    }

    public void addIngrediente(Ingrediente ingre1){
        if (ingredientes.size() <= 7) {
            ingredientes.add(ingre1);
        } else {
            System.out.println("Pizza Especial só aceita até 7 sabores.");
        }
    }

    @Override
    public String toString() {
        return "PizzaEspecial{" +
                " Nome: " + super.getNome() + " Especiale, " +
                " Código: " + super.getCodigo() +
                " Preço: " + super.getPreco() + " reais, " +
                " ingredientes:  " + ingredientes +
                '}';
    }
}
