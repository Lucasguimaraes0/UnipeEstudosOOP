package src.Pizzaria.model.Pizza;

import java.util.List;

public class PizzaTradicional extends Pizza{
    private List<Ingrediente> ingredientes;

    public PizzaTradicional(Integer codigo, Double preco, String nome, List<Ingrediente> ingredientes) {
        super(codigo, preco, nome);
        this.ingredientes = ingredientes;
    }

    public List<Ingrediente> getIngredientes() {
        return ingredientes;
    }

    public void addIngrediente(Ingrediente ingre1){
        if (ingredientes.size() <= 2) {
            ingredientes.add(ingre1);
        } else {
            System.out.println("Pizza Tradicional só aceita até 2 sabores.");
        }
    }

    @Override
    public String toString() {
        return "PizzaTradicional{" +
                " Nome: " + super.getNome() +
                " Código: " + super.getCodigo() +
                " Preço: " + super.getPreco() + " reais, " +
                " ingredientes: " + ingredientes +
                '}';
    }
}