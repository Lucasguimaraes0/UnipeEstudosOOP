package src.Pizzaria.model.Pessoa;

import src.AgendaTelefonica.model.Contato;
import src.Pizzaria.model.Pizza.Pizza;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Cliente extends Pessoa {
    private String endereco;
    private List<Pizza> pizzaFavorita;

    public Cliente(String endereco, List<Pizza> pizzaFavorita) {
        this.endereco = endereco;
        this.pizzaFavorita = pizzaFavorita;
    }

    public Cliente(String endereco) {
        this.endereco = endereco;
    }

    public Cliente(String nome, String cpf, String endereco) {
        super(nome, cpf);
        this.endereco = endereco;
    }

    public Cliente(String nome, String cpf, String endereco, List<Pizza> pizzaFavorita) {
        super(nome, cpf);
        this.endereco = endereco;
        this.pizzaFavorita = pizzaFavorita;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public List<Pizza> getPizzaFavorita() {
        return pizzaFavorita;
    }

    public void addPizzaFavorita(Pizza favorita) {
        pizzaFavorita.add(favorita);
    }

    public Boolean existePizzaFavorita(Pizza favorita){
        for (Pizza p: pizzaFavorita) {
            if (Objects.equals(p.getNome(), pizzaFavorita)){ //compara os nomes
                return true; //encontrou
            }
        }
        return false; //percorreu toda a lista e não encontrou
    }

    public void removePizzaFavorita(Pizza favorita){

    }

    @Override
    public String toString() {
        return "Cliente{" + super.toString() +
                "endereco='" + endereco + '\'' +
                ", pizzaFavorita=" + pizzaFavorita +
                '}';
    }
}
