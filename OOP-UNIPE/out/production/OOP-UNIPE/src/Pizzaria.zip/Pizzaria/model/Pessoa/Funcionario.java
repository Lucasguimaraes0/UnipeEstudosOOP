package src.Pizzaria.model.Pessoa;

import src.Pizzaria.model.Pessoa.Pessoa;

public class Funcionario extends Pessoa {
    private int matricula;
    private double salario;
    private String ctps;

    public Funcionario(int matricula, double salario, String ctps) {
        this.matricula = matricula;
        this.salario = salario;
        this.ctps = ctps;
    }

    public Funcionario(String nome, String cpf, int matricula, double salario, String ctps) {
        super(nome, cpf);
        this.matricula = matricula;
        this.salario = salario;
        this.ctps = ctps;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getCtps() {
        return ctps;
    }

    public void setCtps(String ctps) {
        this.ctps = ctps;
    }

    @Override
    public String toString() {
        return "Funcionario{" + super.toString() +
                "matricula=" + matricula +
                ", salario=" + salario +
                ", ctps='" + ctps + '\'' +
                '}';
    }
}
