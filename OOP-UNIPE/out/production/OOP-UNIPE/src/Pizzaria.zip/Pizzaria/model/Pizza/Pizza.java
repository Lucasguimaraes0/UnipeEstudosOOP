package src.Pizzaria.model.Pizza;

public abstract class Pizza {
    private Integer codigo;
    private Double preco;
    private String nome;

    public Pizza(Integer codigo, Double preco, String nome) {
        this.codigo = codigo;
        this.preco = preco;
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    @Override
    public String toString() {
        return "Pizza{" +
                "codigo=" + codigo +
                ", preco=" + preco +
                ", nome='" + nome + '\'' +
                '}';
    }
}