package src.Pizzaria.app;

import src.Pizzaria.model.Pessoa.Cliente;
import src.Pizzaria.model.Pessoa.Funcionario;
import src.Pizzaria.model.Pizza.Ingrediente;
import src.Pizzaria.model.Pizza.Pizza;
import src.Pizzaria.model.Pizza.PizzaEspecial;
import src.Pizzaria.model.Pizza.PizzaTradicional;

import java.util.ArrayList;
import java.util.List;

public class Pizzaria {
    public static void main(String[] args) {
        Ingrediente ing = new Ingrediente(1, "mussarela", 100);
        Ingrediente ing2 = new Ingrediente(2, "calabresa", 100);
        Ingrediente ing3 = new Ingrediente(3, "camarao", 100);
        Ingrediente ing4 = new Ingrediente(4, "carne", 100);
        Ingrediente ing5 = new Ingrediente(5, "chocolate", 100);
        Ingrediente ing6 = new Ingrediente(6 ,"portuguesa", 100);
        Ingrediente ing7 = new Ingrediente(7, "chocolate", 100);

        List<Ingrediente> ingredientesEspecial = new ArrayList<>();
        ingredientesEspecial.add(ing);
        ingredientesEspecial.add(ing2);
        ingredientesEspecial.add(ing3);
        ingredientesEspecial.add(ing4);
        ingredientesEspecial.add(ing5);
        ingredientesEspecial.add(ing6);
        ingredientesEspecial.add(ing7);

        PizzaEspecial pe1 = new PizzaEspecial(1, 50.5, "pizza Turbinada", ingredientesEspecial);

        List<Ingrediente> ingredientesTradicional = new ArrayList<>();
        ingredientesTradicional.add(ing);
        ingredientesTradicional.add(ing4);

        PizzaTradicional pt1 = new PizzaTradicional(2, 38.9, "Pizza comum", ingredientesTradicional);
        List<Pizza> cardapio = new ArrayList<>();
        cardapio.add(pe1);
        cardapio.add(pt1);

        System.out.println(pe1);

        Funcionario tiaoPizzaiolo = new Funcionario("Tiao", "1234567345", 2424, 2500.00, "1235342");
        List<Funcionario> funcionarios = new ArrayList<>();
        funcionarios.add(tiaoPizzaiolo);

        Cliente marcelo = new Cliente("Marcelo","123132412", "Rua da Areia");
        List<Cliente> clientes = new ArrayList<>();
        clientes.add(marcelo);

        System.out.println(clientes);
        System.out.println(cardapio);
        System.out.println(funcionarios);

        marcelo.addPizzaFavorita(pe1);
        marcelo.addPizzaFavorita(pt1);

//        List<Pizza> list = new ArrayList<Cliente>();


        System.out.println(marcelo);

    }
}
