package src.SistemaBancario.model;

public interface Tributos {
    public abstract double tributar();
}
