package src.SistemaBancario.model.Banco;

import src.SistemaBancario.model.Pessoas.Cliente;
import src.SistemaBancario.model.Tributos;

public class SeguroDeVida implements Tributos {
    private Cliente cliente;
    private double saldoAtual;
    private double valorDepositoMensal;

    public SeguroDeVida() {
    }

    public SeguroDeVida(Cliente cliente, double saldoAtual, double valorDepositoMensal) {
        this.cliente = cliente;
        this.saldoAtual = saldoAtual;
        this.valorDepositoMensal = valorDepositoMensal;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public double getSaldoAtual() {
        return saldoAtual;
    }

    public void setSaldoAtual(double saldoAtual) {
        this.saldoAtual = saldoAtual;
    }

    public double getValorDepositoMensal() {
        return valorDepositoMensal;
    }

    public void setValorDepositoMensal(double valorDepositoMensal) {
        this.valorDepositoMensal = valorDepositoMensal;
    }

    public double tributar(){
        return 42.0;
    }

    @Override
    public String toString() {
        return  "SeguroDeVida{" +
                "cliente=" + cliente +
                ", saldoAtual=" + saldoAtual +
                ", valorDepositoMensal=" + valorDepositoMensal +
                '}';
    }
}
