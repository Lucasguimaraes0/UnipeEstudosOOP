package src.SistemaBancario.model.Banco;

import src.SistemaBancario.model.Pessoas.Cliente;
import src.SistemaBancario.model.Tributos;

public class ContaSalario extends Conta implements Tributos {
    private String empresaAssociada;

    public ContaSalario(Cliente cliente, String numeroConta, String agencia, double saldo, String empresaAssociada) {
        super(cliente, numeroConta, agencia, saldo);
        this.empresaAssociada = empresaAssociada;
    }

    public ContaSalario(String empresaAssociada) {
        this.empresaAssociada = empresaAssociada;
    }

    public String getEmpresaAssociada() {
        return empresaAssociada;
    }

    public void setEmpresaAssociada(String empresaAssociada) {
        this.empresaAssociada = empresaAssociada;
    }

    public double tributar(){
        return (0.02 * super.getSaldo());
    }

    @Override
    public void realizaTransferencia(Conta c1, double valor){

    };

    @Override
    public String toString() {
        return super.toString() + "ContaSalario{" +
                "empresaAssociada='" + empresaAssociada + '\'' +
                '}';
    }
}
