package src.SistemaBancario.model.Banco;

import src.SistemaBancario.model.Pessoas.Cliente;
import src.SistemaBancario.model.Tributos;

public class ContaCorrente extends Conta implements Tributos {
    private double limiteDeSaque;
    private double limiteDeTransferencia;

    public ContaCorrente(Cliente cliente, String numeroConta, String agencia, double saldo, double limiteDeSaque, double limiteDeTransferencia) {
        super(cliente, numeroConta, agencia, saldo);
        this.limiteDeSaque = limiteDeSaque;
        this.limiteDeTransferencia = limiteDeTransferencia;
    }

    public ContaCorrente(double limiteDeSaque, double limiteDeTransferencia) {
        this.limiteDeSaque = limiteDeSaque;
        this.limiteDeTransferencia = limiteDeTransferencia;
    }

    public double getLimiteDeSaque() {
        return limiteDeSaque;
    }

    public void setLimiteDeSaque(double limiteDeSaque) {
        this.limiteDeSaque = limiteDeSaque;
    }

    public double getLimiteDeTransferencia() {
        return limiteDeTransferencia;
    }

    public void setLimiteDeTransferencia(double limiteDeTransferencia) {
        this.limiteDeTransferencia = limiteDeTransferencia;
    }

    public double tributar(){
        return (0.01 * super.getSaldo());
    }

    @Override
    public void realizaTransferencia(Conta c1, double valor){

    };

    @Override
    public String toString() {
        return super.toString() + "ContaCorrente{" +
                "limiteDeSaque=" + limiteDeSaque +
                ", limiteDeTransferencia=" + limiteDeTransferencia +
                '}';
    }
}
