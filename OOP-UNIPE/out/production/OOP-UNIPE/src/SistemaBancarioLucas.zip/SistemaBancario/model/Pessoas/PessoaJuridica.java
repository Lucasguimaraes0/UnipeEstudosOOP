package src.SistemaBancario.model.Pessoas;

public class PessoaJuridica extends Cliente {
    private String cnpj;

    public PessoaJuridica(String nome, String telefone, String endereco, String cnpj) {
        super(nome, telefone, endereco);
        this.cnpj = cnpj;
    }

    public PessoaJuridica(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }
    @Override
    public String getNome(){
        return "Nome fantasia";
    }

    @Override
    public String toString() {
        return "Nome Fantasia: " + PessoaJuridica.super.getNome() +
                "PessoaJuridica{" +
                "cnpj='" + cnpj + '\'' +
                '}';
    }
}
