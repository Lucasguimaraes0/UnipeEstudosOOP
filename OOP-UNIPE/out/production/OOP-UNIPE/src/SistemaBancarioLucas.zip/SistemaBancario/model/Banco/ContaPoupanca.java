package src.SistemaBancario.model.Banco;

import src.SistemaBancario.model.Pessoas.Cliente;

public class ContaPoupanca extends Conta {
    private double taxaRendimentoMensal;

    public ContaPoupanca(Cliente cliente, String numeroConta, String agencia, double saldo, double rendimentoMensal) {
        super(cliente, numeroConta, agencia, saldo);
        this.taxaRendimentoMensal = rendimentoMensal;
    }

    public ContaPoupanca(double rendimentoMensal) {
        this.taxaRendimentoMensal = rendimentoMensal;
    }

    public double getTaxaRendimentoMensal() {
        return taxaRendimentoMensal;
    }

    public void setTaxaRendimentoMensal(double taxaRendimentoMensal) {
        this.taxaRendimentoMensal = taxaRendimentoMensal;
    }
    @Override
    public void realizaTransferencia(Conta c1, double valor){

    };

    @Override
    public String toString() {
        return super.toString() + "ContaPoupanca{" +
                "rendimentoMensal=" + taxaRendimentoMensal +
                '}';
    }
}
